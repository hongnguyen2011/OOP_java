package mytime;


public class TestMyTime {
    public static void main(String[] args)
    {
        MyTime time = new MyTime(20, 59, 59);
        System.out.println("Time: "+ time);
        System.out.println("Next second: " + time.nextSecond());

        time = new MyTime(20, 59, 59);
        System.out.println("Time: "+ time);
        System.out.println("Next minute: " + time.nextMinute());

        time = new MyTime(20, 59, 59);
        System.out.println("Time: "+ time);
        System.out.println("Next hour: " + time.nextHour());



        time = new MyTime(20, 59, 59);
        System.out.println("Time: "+ time);
        System.out.println("Previous second: " + time.previousSecond());

        time = new MyTime(20, 59, 59);
        System.out.println("Time: "+ time);
        System.out.println("Previous minute: " + time.previousMinute());

        time = new MyTime(20, 59, 59);
        System.out.println("Time: "+ time);
        System.out.println("Previous hour: " + time.previousHour());

        time = new MyTime(20, 59, 0);
        System.out.println("Time: "+ time);
        System.out.println("Previous second: " + time.previousSecond());

        time = new MyTime(20, 0, 59);
        System.out.println("Time: "+ time);
        System.out.println("Previous minute: " + time.previousMinute());

        time = new MyTime(0, 59, 59);
        System.out.println("Time: "+ time);
        System.out.println("Previous hour: " + time.previousHour());
    }
}

package countryarraymanager;
import java.util.Arrays;
import java.util.Comparator;

public class CountryArrayManager {
    private Country[] countries;
    private int length;
    private int increment;

    public CountryArrayManager() {
        this.increment = 10;
        countries = new Country[this.increment];
        this.length = 0;
    }

    public CountryArrayManager(int maxLength) {
        this.increment = 10;
        countries = new Country[maxLength];
        this.length = 0;
    }

    public int getLength() {
        return this.length;
    }

    public Country[] getCountries() {
        return this.countries;
    }

    private void correct() {
        int nullFirstIndex = 0;
        for (int i = 0; i < this.countries.length; i++) {
            if (this.countries[i] == null) {
                nullFirstIndex = i;
                break;
            }
        }

        if (nullFirstIndex > 0) {
            this.length = nullFirstIndex;
            for (int i = nullFirstIndex; i < this.countries.length; i++) {
                this.countries[i] = null;
            }
        }
    }

    private void allocateMore() {
        Country[] newArray = new Country[this.countries.length + this.increment];
        System.arraycopy(this.countries, 0, newArray, 0, this.countries.length);
        this.countries = newArray;
    }

    public void append(Country country) {
        if (this.length >= this.countries.length) {
            allocateMore();
        }

        this.countries[this.length] = country;
        this.length++;
    }

    public boolean add(Country country, int index) {
        if ((index < 0) || (index > this.countries.length)) {
            return false;
        }

        if (this.length >= this.countries.length) {
            allocateMore();
        }

        for (int i = this.length; i > index; i--) {
            this.countries[i] = this.countries[i - 1];
        }

        this.countries[index] = country;
        this.length++;
        return true;
    }

    public boolean remove(int index) {
        if ((index < 0) || (index >= countries.length)) {
            return false;
        }

        for (int i = index; i < length - 1; i++) {
            this.countries[i] = this.countries[i + 1];
        }

        this.countries[this.length - 1] = null;
        this.length--;
        return true;
    }

    public Country countryAt(int index) {
        if ((index < 0) || (index >= this.length)) {
            return null;
        }

        return this.countries[index];
    }


    public Country[] sortByIncreasingPopulation() {
        Country[] newArray = new Country[this.length];
        System.arraycopy(this.countries, 0, newArray, 0, this.length);
        int arrLen = this.length;
        int minIdx, minPopulation;
        for (int i = 0; i < arrLen - 1; i++) {
            minIdx = i;
            minPopulation = newArray[i].getPopulation();

            for (int j = i + 1; j < arrLen; j++) {
                if (minPopulation > newArray[j].getPopulation()) {
                    minIdx = j;
                }
            }
            Country temp = newArray[i];
            newArray[i] = newArray[minIdx];
            newArray[minIdx] = temp;

        }

        return newArray;
    }

    public Country[] sortByDecreasingPopulation() {
        Country[] newArray = new Country[this.length];
        System.arraycopy(this.countries, 0, newArray, 0, this.length);
        int arrLen = this.length;
        int maxIdx, maxPopulation;
        for (int i = 0; i < arrLen - 1; i++) {
            maxIdx = i;
            maxPopulation = newArray[i].getPopulation();

            for (int j = i + 1; j < arrLen; j++) {
                if (maxPopulation < newArray[j].getPopulation()) {
                    maxIdx = j;
                }
            }
            Country temp = newArray[i];
            newArray[i] = newArray[maxIdx];
            newArray[maxIdx] = temp;

        }

        return newArray;
    }

    public Country[] sortByIncreasingArea() {
        Country[] newArray = new Country[this.length];
        System.arraycopy(this.countries, 0, newArray, 0, this.length);
        int arrLen = this.length;
        for (int i = 0; i < arrLen - 1; i++) {
            for (int j = 0; j < arrLen - i - 1; j++) {
                if (newArray[j].getArea() > newArray[j+1].getArea()) {
                    Country temp = newArray[j];
                    newArray[j] = newArray[j+1];
                    newArray[j+1] = temp;
                }
            }
        }
        return newArray;
    }

    public Country[] sortByDecreasingArea() {
        Country[] newArray = new Country[this.length];
        System.arraycopy(this.countries, 0, newArray, 0, this.length);
        int arrLen = this.length;
        for (int i = 0; i < arrLen - 1; i++) {
            for (int j = 0; j < arrLen - i - 1; j++) {
                if (newArray[j].getArea() < newArray[j+1].getArea()) {
                    Country temp = newArray[j];
                    newArray[j] = newArray[j+1];
                    newArray[j+1] = temp;
                }
            }
        }
        return newArray;
    }

    public Country[] sortByIncreasingGdp() {
        Country[] newArray = new Country[this.length];
        System.arraycopy(this.countries, 0, newArray, 0, this.length);
        int arrLen = this.length;
        for (int i = 1; i < arrLen; i++) {
            Country key = newArray[i];
            int j = i - 1;
            while (j >= 0 && newArray[j].getGdp() > key.getGdp()) {
                newArray[j + 1] = newArray[j];
                j--;
            }
            newArray[j + 1] = key;
        }
        return newArray;
    }

    public Country[] sortByDecreasingGdp() {
        Country[] newArray = new Country[this.length];
        System.arraycopy(this.countries, 0, newArray, 0, this.length);
        int arrLen = this.length;
        for (int i = 1; i < arrLen; i++) {
            Country key = newArray[i];
            int j = i - 1;
            while (j >= 0 && newArray[j].getGdp() < key.getGdp()) {
                newArray[j + 1] = newArray[j];
                j--;
            }
            newArray[j + 1] = key;
        }
        return newArray;
    }


    public AfricaCountry[] filterAfricaCountry() {
        int countAfrica = 0;
        for (Country country: countries) {
            if (country instanceof AfricaCountry) {
                countAfrica++;
            }
        }
        AfricaCountry[] africaCountry = new AfricaCountry[countAfrica];
        int idx = 0;
        for (Country country: countries) {
            if (country instanceof AfricaCountry) {
                africaCountry[idx] = (AfricaCountry) country;
                idx++;
            }
        }
        return africaCountry;
    }

    public AsiaCountry[] filterAsiaCountry() {
        int countAsia = 0;
        for (Country country: countries) {
            if (country instanceof AsiaCountry) {
                countAsia++;
            }
        }
        AsiaCountry[] asiaCountry = new AsiaCountry[countAsia];
        int idx = 0;
        for (Country country: countries) {
            if (country instanceof AsiaCountry) {
                asiaCountry[idx] = (AsiaCountry) country;
                idx++;
            }
        }
        return asiaCountry;
    }

    public EuropeCountry[] filterEuropeCountry() {
        int countEurope = 0;
        for (Country country: countries) {
            if (country instanceof EuropeCountry) {
                countEurope++;
            }
        }
        EuropeCountry[] europeCountry = new EuropeCountry[countEurope];
        int idx = 0;
        for (Country country: countries) {
            if (country instanceof EuropeCountry) {
                europeCountry[idx] = (EuropeCountry) country;
                idx++;
            }
        }
        return europeCountry;
    }

    public NorthAmericaCountry[] filterNorthAmericaCountry() {
        int countNorAmerica = 0;
        for (Country country: countries) {
            if (country instanceof NorthAmericaCountry) {
                countNorAmerica++;
            }
        }
        NorthAmericaCountry[] norAmericaCountry = new NorthAmericaCountry[countNorAmerica];
        int idx = 0;
        for (Country country: countries) {
            if (country instanceof NorthAmericaCountry) {
                norAmericaCountry[idx] = (NorthAmericaCountry) country;
                idx++;
            }
        }
        return norAmericaCountry;
    }

    public OceaniaCountry[] filterOceaniaCountry() {
        int countOceCountry = 0;
        for (Country country: countries) {
            if (country instanceof OceaniaCountry) {
                countOceCountry++;
            }
        }
        OceaniaCountry[] oceaniaCountry = new OceaniaCountry[countOceCountry];
        int idx = 0;
        for (Country country: countries) {
            if (country instanceof OceaniaCountry) {
                oceaniaCountry[idx] = (OceaniaCountry) country;
                idx++;
            }
        }
        return oceaniaCountry;
    }

    public SouthAmericaCountry[] filterSouthAmericaCountry() {
        int countSouAmerica = 0;
        for (Country country: countries) {
            if (country instanceof SouthAmericaCountry) {
                countSouAmerica++;
            }
        }
        SouthAmericaCountry[] souAmericaCountry = new SouthAmericaCountry[countSouAmerica];
        int idx = 0;
        for (Country country: countries) {
            if (country instanceof SouthAmericaCountry) {
                souAmericaCountry[idx] = (SouthAmericaCountry) country;
                idx++;
            }
        }
        return souAmericaCountry;
    }

    public Country[] filterMostPopulousCountries(int howMany) {
        Country[] newArray = sortByDecreasingPopulation();
        Country[] country = new Country[howMany];
        for (int idx = 0; idx < howMany; idx++) {
            country[idx] = newArray[idx];
        }
        return country;
    }

    public Country[] filterLeastPopulousCountries(int howMany) {
        Country[] newArray = sortByIncreasingPopulation();
        Country[] country = new Country[howMany];
        for (int idx = 0; idx < howMany; idx++) {
            country[idx] = newArray[idx];
        }
        return country;
    }

    public Country[] filterLargestAreaCountries(int howMany) {
        Country[] newArray = sortByDecreasingArea();
        Country[] country = new Country[howMany];
        for (int idx = 0; idx < howMany; idx++) {
            country[idx] = newArray[idx];
        }
        return country;
    }

    public Country[] filterSmallestAreaCountries(int howMany) {
        Country[] newArray = sortByIncreasingArea();
        Country[] country = new Country[howMany];
        for (int idx = 0; idx < howMany; idx++) {
            country[idx] = newArray[idx];
        }
        return country;
    }

    public Country[] filterHighestGdpCountries(int howMany) {
        Country[] newArray = sortByDecreasingGdp();
        Country[] country = new Country[howMany];
        for (int idx = 0; idx < howMany; idx++) {
            country[idx] = newArray[idx];
        }
        return country;
    }

    public Country[] filterLowestGdpCountries(int howMany) {
        Country[] newArray = sortByIncreasingGdp();
        Country[] country = new Country[howMany];
        for (int idx = 0; idx < howMany; idx++) {
            country[idx] = newArray[idx];
        }
        return country;
    }

    public static String codeOfCountriesToString(Country[] countries) {
        StringBuilder codeOfCountries = new StringBuilder();
        codeOfCountries.append("[");
        for (int i = 0; i < countries.length; i++) {
            Country country = countries[i];
            if (country != null) {
                codeOfCountries.append(country.getCode())
                        .append(" ");
            }
        }

        return codeOfCountries.toString().trim() + "]";
    }

    public static void print(Country[] countries) {
        StringBuilder countriesString = new StringBuilder();
        countriesString.append("[");
        for (int i = 0; i < countries.length; i++) {
            Country country = countries[i];
            if (country != null) {
                countriesString.append((country.getName() + " "));
            }
        }
        System.out.print(countriesString.toString().trim() + "]");
    }
}

package bouncingball;

public class TestBallContainer {
    public static void main(String[] args) {
        Ball ball1 = new Ball(50, 50, 30, 10, 45);
        //Test Ball
        System.out.println("The X coordinate of ball is: "+ball1.getX());
        System.out.println("The Y coordinate of ball is: "+ball1.getY());
        System.out.println("The Radius of ball is: "+ball1.getRadius());
        System.out.println(ball1);

        ball1.setX(100);
        ball1.setY(100);
        ball1.setRadius(20);
        System.out.println(ball1);

        ball1.setXY(200, 200);
        System.out.println(ball1);

        ball1.move();
        System.out.println(ball1);

        ball1.reflectHorizontal();
        ball1.move();
        System.out.println(ball1);

        ball1.reflectVertical();
        ball1.move();
        System.out.println(ball1);

        //Test Container
        Ball ball = new Ball(50,50,5,10,30);
        Container box = new Container(0,0,100,100);
        for(int step = 0; step < 100; ++step){
            ball.move();
            box.collidesWith(ball);
            System.out.println(ball);
        }
    }
}

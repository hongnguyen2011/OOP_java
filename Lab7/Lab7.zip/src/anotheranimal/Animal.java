package anotheranimal;

abstract public class Animal {
    abstract public void greets();
}
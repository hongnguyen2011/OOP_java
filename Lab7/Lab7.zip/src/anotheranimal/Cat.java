package anotheranimal;

public class Cat extends Animal {
    @Override
    public void greets() {
        System.out.println("Meow!");
    }
}
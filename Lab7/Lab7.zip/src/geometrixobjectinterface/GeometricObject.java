package geometrixobjectinterface;

public interface GeometricObject {
    double getArea();
    double getPerimeter();
}

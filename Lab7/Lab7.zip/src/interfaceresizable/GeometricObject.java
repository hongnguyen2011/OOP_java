package interfaceresizable;

public interface GeometricObject {
    double getArea();

    double getPerimeter();
}
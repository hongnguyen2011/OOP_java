package interfaceresizable;

public interface Resizable {
    void resize(int percent);
}